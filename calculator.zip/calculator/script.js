let Result=document.getElementById("display");
function insertValue(val){
    Result.value +=val;
}

function allclear(){
    Result.value="";
}

function deleteone(){
    Result.value=Result.value.slice(0,-1);
}

function calculate(){
    try{
        Result.value=eval(Result.value);
    }
    catch(error){
        Result.value="error..";
    }
}